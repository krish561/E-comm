#!/bin/bash

# Check if required software is installed
check_software() {
    echo "Checking required software..."
    
    # Check Java
    if ! command -v java &> /dev/null; then
        echo "❌ Java 17 is not installed. Please install it from: https://adoptium.net/"
        exit 1
    fi
    
    # Check Maven
    if ! command -v mvn &> /dev/null; then
        echo "❌ Maven is not installed. Please install it from: https://maven.apache.org/download.cgi"
        exit 1
    fi
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        echo "❌ Node.js is not installed. Please install it from: https://nodejs.org/"
        exit 1
    fi
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        echo "❌ Docker is not installed. Please install it from: https://www.docker.com/products/docker-desktop"
        exit 1
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        echo "❌ Docker Compose is not installed. Please install it from: https://docs.docker.com/compose/install/"
        exit 1
    fi
    
    echo "✅ All required software is installed!"
}

# Start the application
start_application() {
    echo "🚀 Starting E-Commerce Platform..."
    
    # Start infrastructure services
    echo "Starting infrastructure services (Kafka, Redis, PostgreSQL)..."
    docker-compose up -d
    
    # Wait for services to be ready
    echo "Waiting for services to be ready..."
    sleep 10
    
    # Build backend services
    echo "Building backend services..."
    mvn clean install
    
    # Start backend services in background
    echo "Starting backend services..."
    cd order-service && mvn spring-boot:run &
    cd ../inventory-service && mvn spring-boot:run &
    cd ../payment-service && mvn spring-boot:run &
    
    # Start frontend
    echo "Starting frontend..."
    cd ../frontend
    npm install
    npm start
}

# Main execution
echo "🔍 Checking prerequisites..."
check_software

echo "📦 Starting application..."
start_application 