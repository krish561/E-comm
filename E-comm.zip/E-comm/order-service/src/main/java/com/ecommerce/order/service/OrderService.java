package com.ecommerce.order.service;

import com.ecommerce.order.event.OrderEvent;
import com.ecommerce.order.model.Order;
import com.ecommerce.order.model.OrderStatus;
import com.ecommerce.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, OrderEvent> kafkaTemplate;

    @Transactional
    public Order createOrder(Order order) {
        order.setOrderDate(LocalDateTime.now());
        order.setStatus(OrderStatus.CREATED);
        Order savedOrder = orderRepository.save(order);

        // Publish order created event
        OrderEvent event = new OrderEvent("ORDER_CREATED", savedOrder, "New order created");
        kafkaTemplate.send("order-events", event);

        return savedOrder;
    }

    @Cacheable(value = "orders", key = "#id")
    public Order getOrder(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    @Cacheable(value = "orders")
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Transactional
    @CacheEvict(value = "orders", key = "#order.id")
    public Order updateOrderStatus(Long orderId, OrderStatus newStatus) {
        Order order = getOrder(orderId);
        order.setStatus(newStatus);
        Order updatedOrder = orderRepository.save(order);

        // Publish order status updated event
        OrderEvent event = new OrderEvent("ORDER_STATUS_UPDATED", updatedOrder, 
            "Order status updated to " + newStatus);
        kafkaTemplate.send("order-events", event);

        return updatedOrder;
    }

    @Transactional
    @CacheEvict(value = "orders", key = "#id")
    public void cancelOrder(Long id) {
        Order order = getOrder(id);
        order.setStatus(OrderStatus.CANCELLED);
        orderRepository.save(order);

        // Publish order cancelled event
        OrderEvent event = new OrderEvent("ORDER_CANCELLED", order, "Order cancelled");
        kafkaTemplate.send("order-events", event);
    }
} 