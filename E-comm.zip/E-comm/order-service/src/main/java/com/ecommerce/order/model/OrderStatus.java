package com.ecommerce.order.model;

public enum OrderStatus {
    CREATED,
    PENDING_PAYMENT,
    PAYMENT_RECEIVED,
    INVENTORY_CHECKED,
    SHIPPED,
    DELIVERED,
    CANCELLED
} 