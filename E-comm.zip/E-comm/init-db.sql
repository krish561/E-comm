-- Check if products table exists, if not create it
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(255),
    stock_quantity INTEGER NOT NULL DEFAULT 0,
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert products if they don't exist
INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Wireless Noise-Cancelling Headphones', 'Premium wireless headphones with active noise cancellation', 199.99, 'https://via.placeholder.com/300', 50, 'Electronics'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Wireless Noise-Cancelling Headphones');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Smart Fitness Watch', 'Track your health and fitness with this advanced smartwatch', 149.99, 'https://via.placeholder.com/300', 30, 'Wearables'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Smart Fitness Watch');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Ultra HD 4K Monitor', '27-inch 4K display with HDR support', 399.99, 'https://via.placeholder.com/300', 20, 'Electronics'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Ultra HD 4K Monitor');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Mechanical Gaming Keyboard', 'RGB backlit mechanical keyboard with Cherry MX switches', 129.99, 'https://via.placeholder.com/300', 40, 'Gaming'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Mechanical Gaming Keyboard');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Wireless Gaming Mouse', 'High-precision wireless gaming mouse with RGB lighting', 79.99, 'https://via.placeholder.com/300', 35, 'Gaming'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Wireless Gaming Mouse');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Portable SSD 1TB', 'Ultra-fast portable SSD with USB-C connection', 159.99, 'https://via.placeholder.com/300', 25, 'Storage'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Portable SSD 1TB');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Smart Home Security Camera', '1080p wireless security camera with night vision', 89.99, 'https://via.placeholder.com/300', 15, 'Smart Home'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Smart Home Security Camera');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Bluetooth Speaker', 'Waterproof portable speaker with 360° sound', 129.99, 'https://via.placeholder.com/300', 30, 'Audio'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Bluetooth Speaker');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Gaming Console', 'Next-gen gaming console with 4K graphics', 499.99, 'https://via.placeholder.com/300', 10, 'Gaming'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Gaming Console');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Wireless Charging Pad', 'Fast wireless charging pad for smartphones', 39.99, 'https://via.placeholder.com/300', 45, 'Accessories'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Wireless Charging Pad');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'Smart LED Light Bulbs', 'Color-changing smart LED bulbs with app control', 29.99, 'https://via.placeholder.com/300', 60, 'Smart Home'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Smart LED Light Bulbs');

INSERT INTO products (name, description, price, image_url, stock_quantity, category)
SELECT 'USB-C Hub', '7-in-1 USB-C hub with HDMI and card reader', 49.99, 'https://via.placeholder.com/300', 40, 'Accessories'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'USB-C Hub'); 