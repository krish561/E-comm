import {
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
} from "@mui/material";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";

const Products = () => {
  const products = [
    {
      id: 1,
      name: "Wireless Noise-Cancelling Headphones",
      price: 199.99,
      description: "Premium wireless headphones with active noise cancellation",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 2,
      name: "Smart Fitness Watch",
      price: 149.99,
      description:
        "Track your health and fitness with this advanced smartwatch",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 3,
      name: "Ultra HD 4K Monitor",
      price: 399.99,
      description: "27-inch 4K display with HDR support",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 4,
      name: "Mechanical Gaming Keyboard",
      price: 129.99,
      description: "RGB backlit mechanical keyboard with Cherry MX switches",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 5,
      name: "Wireless Gaming Mouse",
      price: 79.99,
      description: "High-precision wireless gaming mouse with RGB lighting",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 6,
      name: "Portable SSD 1TB",
      price: 159.99,
      description: "Ultra-fast portable SSD with USB-C connection",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 7,
      name: "Smart Home Security Camera",
      price: 89.99,
      description: "1080p wireless security camera with night vision",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 8,
      name: "Bluetooth Speaker",
      price: 129.99,
      description: "Waterproof portable speaker with 360° sound",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 9,
      name: "Gaming Console",
      price: 499.99,
      description: "Next-gen gaming console with 4K graphics",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 10,
      name: "Wireless Charging Pad",
      price: 39.99,
      description: "Fast wireless charging pad for smartphones",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 11,
      name: "Smart LED Light Bulbs",
      price: 29.99,
      description: "Color-changing smart LED bulbs with app control",
      image: "https://via.placeholder.com/300",
    },
    {
      id: 12,
      name: "USB-C Hub",
      price: 49.99,
      description: "7-in-1 USB-C hub with HDMI and card reader",
      image: "https://via.placeholder.com/300",
    },
  ];

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Our Products
      </Typography>
      <Grid container spacing={3}>
        {products.map((product) => (
          <Grid item key={product.id} xs={12} sm={6} md={4} lg={3}>
            <Card
              sx={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
                transition: "transform 0.2s",
                "&:hover": {
                  transform: "scale(1.02)",
                  boxShadow: 3,
                },
              }}
            >
              <Box
                sx={{
                  position: "relative",
                  paddingTop: "100%", // 1:1 Aspect ratio
                  overflow: "hidden",
                }}
              >
                <CardMedia
                  component="img"
                  sx={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                  }}
                  image={product.image}
                  alt={product.name}
                />
              </Box>
              <CardContent
                sx={{ flexGrow: 1, display: "flex", flexDirection: "column" }}
              >
                <Typography
                  gutterBottom
                  variant="h6"
                  component="h2"
                  sx={{
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                  }}
                >
                  {product.name}
                </Typography>
                <Typography
                  color="text.secondary"
                  sx={{
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                    mb: 2,
                  }}
                >
                  {product.description}
                </Typography>
                <Box
                  sx={{
                    mt: "auto",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <Typography variant="h6" color="primary">
                    ${product.price}
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<AddShoppingCartIcon />}
                    size="small"
                  >
                    Add to Cart
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Products;
