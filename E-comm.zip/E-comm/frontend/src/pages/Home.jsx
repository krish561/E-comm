import { Container, Typography, Box, Button } from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";

const Home = () => {
  return (
    <Container maxWidth="md" sx={{ mt: 8, textAlign: "center" }}>
      <Typography variant="h2" component="h1" gutterBottom>
        Welcome to Our E-Commerce Store
      </Typography>
      <Typography variant="h5" color="text.secondary" paragraph>
        Discover our wide range of products at competitive prices
      </Typography>
      <Box sx={{ mt: 4 }}>
        <Button
          component={RouterLink}
          to="/products"
          variant="contained"
          color="primary"
          size="large"
          startIcon={<ShoppingCartIcon />}
          sx={{ mr: 2 }}
        >
          Browse Products
        </Button>
      </Box>
    </Container>
  );
};

export default Home;
