import {
  Container,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  Box,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import PendingIcon from "@mui/icons-material/Pending";

const Orders = () => {
  // Dummy orders data
  const orders = [
    {
      id: "ORD-001",
      date: "2024-03-15",
      status: "Delivered",
      total: 349.98,
      items: [
        {
          name: "Wireless Noise-Cancelling Headphones",
          quantity: 1,
          price: 199.99,
        },
        { name: "Smart Fitness Watch", quantity: 1, price: 149.99 },
      ],
    },
    {
      id: "ORD-002",
      date: "2024-03-10",
      status: "Shipped",
      total: 499.99,
      items: [{ name: "Gaming Console", quantity: 1, price: 499.99 }],
    },
    {
      id: "ORD-003",
      date: "2024-03-05",
      status: "Processing",
      total: 129.99,
      items: [
        { name: "Mechanical Gaming Keyboard", quantity: 1, price: 129.99 },
      ],
    },
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case "Delivered":
        return <CheckCircleIcon color="success" />;
      case "Shipped":
        return <LocalShippingIcon color="primary" />;
      case "Processing":
        return <PendingIcon color="warning" />;
      default:
        return null;
    }
  };

  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Your Orders
      </Typography>

      {orders.length === 0 ? (
        <Typography variant="h6" color="text.secondary" align="center">
          You haven't placed any orders yet
        </Typography>
      ) : (
        <Grid container spacing={3}>
          {orders.map((order) => (
            <Grid item xs={12} key={order.id}>
              <Card>
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Typography variant="h6" gutterBottom>
                        Order {order.id}
                      </Typography>
                      <Typography color="text.secondary">
                        Placed on {order.date}
                      </Typography>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      sx={{ textAlign: { sm: "right" } }}
                    >
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: { xs: "flex-start", sm: "flex-end" },
                          gap: 1,
                        }}
                      >
                        {getStatusIcon(order.status)}
                        <Chip
                          label={order.status}
                          color={
                            order.status === "Delivered"
                              ? "success"
                              : order.status === "Shipped"
                              ? "primary"
                              : "warning"
                          }
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography variant="subtitle1" gutterBottom>
                        Items:
                      </Typography>
                      {order.items.map((item, index) => (
                        <Typography key={index} color="text.secondary">
                          {item.quantity}x {item.name} - ${item.price}
                        </Typography>
                      ))}
                    </Grid>
                    <Grid item xs={12}>
                      <Typography variant="h6" sx={{ textAlign: "right" }}>
                        Total: ${order.total.toFixed(2)}
                      </Typography>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
};

export default Orders;
