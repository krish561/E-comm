package com.ecommerce.inventory.service;

import com.ecommerce.inventory.model.Product;
import com.ecommerce.inventory.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final ProductRepository productRepository;
    private final KafkaTemplate<String, Object> kafkaTemplate;

    @Transactional
    public Product createProduct(Product product) {
        Product savedProduct = productRepository.save(product);
        kafkaTemplate.send("inventory-events", "PRODUCT_CREATED", savedProduct);
        return savedProduct;
    }

    @Cacheable(value = "products", key = "#id")
    public Product getProduct(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    @Cacheable(value = "products")
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public Product updateStock(Long id, Integer quantity) {
        Product product = getProduct(id);
        product.setQuantity(quantity);
        Product updatedProduct = productRepository.save(product);
        
        kafkaTemplate.send("inventory-events", "STOCK_UPDATED", updatedProduct);
        return updatedProduct;
    }

    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public Product updateProduct(Long id, Product productDetails) {
        Product product = getProduct(id);
        product.setName(productDetails.getName());
        product.setDescription(productDetails.getDescription());
        product.setPrice(productDetails.getPrice());
        product.setQuantity(productDetails.getQuantity());
        
        Product updatedProduct = productRepository.save(product);
        kafkaTemplate.send("inventory-events", "PRODUCT_UPDATED", updatedProduct);
        return updatedProduct;
    }

    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public void deleteProduct(Long id) {
        Product product = getProduct(id);
        productRepository.delete(product);
        kafkaTemplate.send("inventory-events", "PRODUCT_DELETED", product);
    }
} 